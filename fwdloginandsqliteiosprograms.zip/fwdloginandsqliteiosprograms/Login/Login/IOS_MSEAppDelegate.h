//
//  IOS_MSEAppDelegate.h
//  Login
//
//  Created by pesit on 03/09/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class IOS_MSEViewController;

@interface IOS_MSEAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) IOS_MSEViewController *viewController;

@end
