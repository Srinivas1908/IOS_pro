//
//  tempAppDelegate.h
//  lab5
//
//  Created by MSE on 15/09/13.
//  Copyright (c) 2013 MSE. All rights reserved.
//

#import <UIKit/UIKit.h>

@class tempViewController;

@interface tempAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) tempViewController *viewController;

@end
